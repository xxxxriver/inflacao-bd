#INTRODUÇÃO, CRIAÇÃO DE PROJETO NO R STUDIO, DATASET DISPONÍVEL EM: https://basedosdados.org/dataset/br-ibge-inpc
install.packages(read.csv)
df <- read.csv(file = "mes_brasil.csv")
View(df)
attach(df)
#temos 514 observações de 8 variáveis

#pacotes utilizados
install.packages("ggplot")
install.packages("ggplot2")
library(ggplot)
library(ggplot2)

#visualização da variável "índice"
ggplot(df) +
  (aes(x = ano)) + 
  geom_line(aes(y = indice, color = "INPC de mar/1979 a dez/2021")) +
  ggthemes::theme_fivethirtyeight() + 
  labs(x = "Tempo", y = "",
       title = "Índice",
       subtitle = "INPC de mar/1979 a dez/2021",
       color = "Modelo:")

#visualização da variável "variacao_mensal"
ggplot(df) +
  (aes(x = ano)) + 
  geom_line(aes(y = variacao_mensal, color = "Variação mensal do INPC de mar/1979 a dez/2021")) +
  ggthemes::theme_fivethirtyeight() + 
  labs(x = "Tempo", y = "",
       title = "Variação mensal",
       subtitle = "INPC de mar/1979 a dez/2021",
       color = "Modelo:")

#visualização da variável "variacao_doze_meses"
ggplot(df) +
  (aes(x = ano)) + 
  geom_line(aes(y = variacao_doze_meses, color = "Variação acumulada 12 meses")) +
  ggthemes::theme_fivethirtyeight() + 
  labs(x = "Tempo", y = "",
       title = "Variação acumulada",
       subtitle = "Variação acumulada últimos 12 meses do INPC",
       color = "Modelo:")

#visualização da variação percentual mensal em comparação com a variação dos últimos 12 meses 
ggplot(df) +
  (aes(x = ano)) + 
  geom_line(aes(y = variacao_mensal, color = "Variação Mensal")) +
  geom_line(aes(y = variacao_doze_meses, color = "Variação doze meses")) +
  ggthemes::theme_fivethirtyeight() + 
  labs(x = "Tempo", y = "",
       title = "Comparação INPC",
       subtitle = "Variação mensal vs. Variação doze meses",
       color = "Modelo:")

#visualização da variação percentual trimestral
ggplot(df) +
  (aes(x = ano)) + 
  geom_line(aes(y = variacao_trimestral, color = "Variação Trimestral")) +
  ggthemes::theme_fivethirtyeight() + 
  labs(x = "Tempo", y = "",
       title = "Variação trimestral",
       subtitle = "Variação trimestral do INPC",
       color = "Modelo:")

#visualização da variação percentual semestral
ggplot(df) +
  (aes(x = ano)) + 
  geom_line(aes(y = variacao_semestral, color = "Variação Semestral")) +
  ggthemes::theme_fivethirtyeight() + 
  labs(x = "Tempo", y = "",
       title = "Variação semestral",
       subtitle = "Variação semestral do INPC",
       color = "Modelo:")

#visualização da variação percentual anual
ggplot(df) +
  (aes(x = ano)) + 
  geom_line(aes(y = variacao_anual, color = "Variação Anual")) +
  ggthemes::theme_fivethirtyeight() + 
  labs(x = "Tempo", y = "",
       title = "Variação anual",
       subtitle = "Variação anual do INPC",
       color = "Modelo:")

#visualização da variacão percentual anual em outro formato
ggplot(df) +
  geom_col(aes(x = ano, y = variacao_anual)) +
  geom_col(
    aes(y = variacao_anual, x = ano, fill = ano),
    show.legend = FALSE
  )

#visualização da variação percentual anual com linha de tendência
#para este caso é feita uma regressão linear
ggplot(df, aes(x = ano, y = variacao_anual)) +
  geom_point() +
  geom_smooth(method = lm)



#visualização variacao anual de 2000 a 2021
plot(df$ano, df$variacao_anual, 
     xlab = "Período", ylab = "INPC",  
     main = "Visualização INPC de jan/2000 a dez/2021",
     las = 1, 
     xlim = c(2000, 2022), ylim = c(0, 20), 
     xaxs = "i", yaxs = "i", 
     cex.axis = 1)

